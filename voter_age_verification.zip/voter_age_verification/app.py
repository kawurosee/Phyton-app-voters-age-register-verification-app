from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/verify', methods=['POST'])
def verify():
    data = request.get_json()
    name = data.get('name')
    age = data.get('age')

    if not name or age is None:
        return jsonify({'status': 'error', 'message': 'Name and age are required.'}), 400

    try:
        age = int(age)
    except ValueError:
        return jsonify({'status': 'error', 'message': 'Age must be a number.'}), 400

    if age >= 18:
        return jsonify({'status': 'success', 'message': f'{name} is eligible to vote.'})
    else:
        return jsonify({'status': 'fail', 'message': f'{name} is not eligible to vote.'})

if __name__ == '__main__':
    app.run(debug=True)