const form = document.getElementById('voterForm');
const result = document.getElementById('result');

form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const age = document.getElementById('age').value;

    try {
        const response = await fetch('/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, age })
        });

        const data = await response.json();

        if(data.status === 'success' || data.status === 'fail') {
            result.textContent = data.message;
            result.style.color = data.status === 'success' ? 'green' : 'red';
        } else {
            result.textContent = 'Error: ' + data.message;
            result.style.color = 'orange';
        }
    } catch (error) {
        result.textContent = 'Error: Unable to connect to server.';
        result.style.color = 'orange';
    }
});